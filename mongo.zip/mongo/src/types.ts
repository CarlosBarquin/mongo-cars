export type car = {
    Plate: string,
    seats: number,
    free : boolean
}
